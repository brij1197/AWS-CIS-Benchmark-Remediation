import boto3
from botocore.exceptions import ClientError


def handler(event, context):
    updateSecurityGroups()


def updateSecurityGroups():
    region = "us-east-1"
    session = boto3.Session(region_name=region)
    ec2 = session.client("ec2", region_name=region)

    try:
        group = ec2.describe_security_groups()["SecurityGroups"]
    except ClientError as e:
        print(e.response["Error"]["Message"])
        return

    for sec_group in group:
        if sec_group["GroupName"] == "default":
            sg_id = sec_group["GroupId"]

            try:
                ingress_perms = sec_group["IpPermissions"]
            except (IndexError, KeyError):
                ingress_perms = ""

            for ip_perm in ingress_perms:
                remove_sg_rule(ec2, sg_id, ip_perm, revoke="ingress")

            try:
                egress_perms = sec_group["IpPermissionsEgress"]
            except (IndexError, KeyError):
                egress_perms = ""

            for ip_perm in egress_perms:
                remove_sg_rule(ec2, sg_id, ip_perm, revoke="egress")

                return
            

            pass  # CIS 4.3 here.
        else:
            pass  # CIS 4.1 4.2 here

        

        
    # # Revoke all egress permissions
    # try:
    #   egress_perms = group[0]['IpPermissionsEgress']
    # except (IndexError, KeyError):
    #   egress_perms = ''

    # for ip_perm in egress_perms:
    #   remove_sg_rule(ec2, sg_id, ip_perm, revoke='egress')

    # return


def remove_sg_rule(ec2, sg_id, ip_perm, revoke):

    revoke_args = {"GroupId": sg_id, "IpPermissions": [ip_perm]}

    if revoke == "ingress":
        try:
            ec2.revoke_security_group_ingress(**revoke_args)
        except ClientError as e:
            print(e.response["Error"]["Message"])
            return

    elif revoke == "egress":
        try:
            ec2.revoke_security_group_egress(**revoke_args)
        except ClientError as e:
            print(e.response["Error"]["Message"])
            return
    else:
        return

    print(
        "Revoked {} rule {} from default security group {}.".format(
            revoke, ip_perm, sg_id
        )
    )

    return


updateSecurityGroups()
