import boto3
from botocore.exceptions import ClientError

from pprint import pprint


def handler(event, context):
    updateSecurityGroups()


def updateSecurityGroups():
    region = "us-east-1"
    session = boto3.Session(region_name=region)
    ec2 = session.client("ec2", region_name=region)

    try:
        group = ec2.describe_security_groups()["SecurityGroups"]
    except ClientError as e:
        print(e.response["Error"]["Message"])
        return

    for sec_group in group:
        sg_id = sec_group["GroupId"]
        if sec_group["GroupName"] == "default":  # CIS 4.3 implemented

            try:
                ingress_perms = sec_group["IpPermissions"]
            except (IndexError, KeyError):
                ingress_perms = ""

            for ip_perm in ingress_perms:
                remove_sg_rule(ec2, sg_id, ip_perm, revoke="ingress")

            try:
                egress_perms = sec_group["IpPermissionsEgress"]
            except (IndexError, KeyError):
                egress_perms = ""

            for ip_perm in egress_perms:
                remove_sg_rule(ec2, sg_id, ip_perm, revoke="egress")
                return
        else:
            try:
                ingress_perms = sec_group["IpPermissions"]
            except (IndexError, KeyError):
                ingress_perms = ""

            for ip_perm in ingress_perms:
                if (
                    int(ip_perm["FromPort"]) == 22
                    or int(ip_perm["ToPort"]) == 22
                    or (ip_perm["FromPort"] < 22 and ip_perm["ToPort"] > 22)
                ):  # CIS 4.1
                    for ip_range in ip_perm["IpRanges"]:
                        if ip_range["CidrIp"] == "0.0.0.0/0":
                            remove_sg_rule(ec2, sg_id, ip_perm, revoke="ingress")
                            return

                    for ip_range in ip_perm["Ipv6Ranges"]:
                        if ip_range["CidrIpv6"] == ": :/0":
                            remove_sg_rule(ec2, sg_id, ip_perm, revoke="ingress")
                            return

                if (
                    int(ip_perm["FromPort"]) == 3389
                    or int(ip_perm["ToPort"]) == 3389
                    or (ip_perm["FromPort"] < 3389 and ip_perm["ToPort"] > 3389)
                ):  # CIS 4.2
                    for ip_range in ip_perm["IpRanges"]:
                        if ip_range["CidrIp"] == "0.0.0.0/0":
                            remove_sg_rule(ec2, sg_id, ip_perm, revoke="ingress")
                            return

                    for ip_range in ip_perm["Ipv6Ranges"]:
                        if ip_range["CidrIpv6"] == "::/0":
                            remove_sg_rule(ec2, sg_id, ip_perm, revoke="ingress")
                            return


def remove_sg_rule(ec2, sg_id, ip_perm, revoke):

    revoke_args = {"GroupId": sg_id, "IpPermissions": [ip_perm]}

    if revoke == "ingress":
        try:
            ec2.revoke_security_group_ingress(**revoke_args)
        except ClientError as e:
            print(e.response["Error"]["Message"])
            return

    elif revoke == "egress":
        try:
            ec2.revoke_security_group_egress(**revoke_args)
        except ClientError as e:
            print(e.response["Error"]["Message"])
            return
    else:
        return

    print(
        "Revoked {} rule {} from default security group {}.".format(
            revoke, ip_perm, sg_id
        )
    )

    return


updateSecurityGroups()
