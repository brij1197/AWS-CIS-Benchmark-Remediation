from asyncio import events
from aws_cdk import (
    Duration,
    Stack,
    aws_s3 as s3,
    aws_logs as logs,
    aws_iam as iam,
    aws_lambda,
    aws_events,
    PhysicalName,
    Duration,
    aws_config as config,
    aws_cloudtrail as cloudtrail,
    aws_events_targets as targets,
    aws_cloudwatch as cloudwatch,
    aws_cloudwatch_actions as actions,
    aws_sns as sns,
    # aws_sqs as sqs,
)
from constructs import Construct

from pathlib import Path


class CisComplianceStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # The code that defines your stack goes here

        cisComlpianceBucket = s3.Bucket(
            self,
            "CisComlpianceBucket",
            bucket_name=PhysicalName.GENERATE_IF_NEEDED,
            block_public_access=s3.BlockPublicAccess(  # CIS 2.3
                block_public_acls=True,
                block_public_policy=True,
                ignore_public_acls=True,
                restrict_public_buckets=True,
            ),
        )

        cisComplianceLogGroup = logs.LogGroup(
            self,
            "CisComplianceLogGroup",
            log_group_name=PhysicalName.GENERATE_IF_NEEDED,
            retention=logs.RetentionDays.ONE_YEAR,
        )

        # cisComplianceConfig = config.

        cisComplianceCloudtrail = cloudtrail.Trail(
            self,
            "CisComplianceCloudtrail",
            bucket=cisComlpianceBucket,
            cloud_watch_log_group=cisComplianceLogGroup,
            cloud_watch_logs_retention=logs.RetentionDays.ONE_YEAR,
            is_multi_region_trail=True,  # CIS 2.1
            enable_file_validation=True,  # CIS 2.2
            send_to_cloud_watch_logs=True,  # CIS 2.4
            trail_name="cisComplianceCloudtrail",
        )

        cisPasswordPolicyLambdaRole = iam.Role(
            self,
            "CisPasswordPolicyLambdaRole",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
        )

        cisPasswordPolicyLambdaRole.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AdministratorAccess")
        )

        cisPasswordPolicyLambda = aws_lambda.Function(
            self,
            "CisPasswordPolicyLambda",
            runtime=aws_lambda.Runtime.PYTHON_3_8,
            role=cisPasswordPolicyLambdaRole,
            handler="cis_password_policy_lambda.handler",
            code=aws_lambda.Code.from_asset(
                str(Path.joinpath(Path.cwd(), "lambda/cisPasswordPolicyLambda"))
            ),
            timeout=Duration.seconds(60),
        )

        cisPasswordPolicyLambdaCron = aws_events.Rule(
            self,
            "CisPasswordPolicyLambdaCron",
            schedule=aws_events.Schedule.expression("cron(0 8 1 * ? *)"),
        )

        cisPasswordPolicyLambdaCron.add_target(
            targets.LambdaFunction(cisPasswordPolicyLambda)
        )

        ####################################################################################

        cisSecurityGroupLambdaRole = iam.Role(
            self,
            "CisSecurityGroupLambdaRole",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
        )

        cisSecurityGroupLambdaRole.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AdministratorAccess")
        )

        cisSecurityGroupLambda = aws_lambda.Function(
            self,
            "CisSecurityGroupLambda",
            runtime=aws_lambda.Runtime.PYTHON_3_8,
            role=cisSecurityGroupLambdaRole,
            handler="cis_security_group_lambda.handler",
            code=aws_lambda.Code.from_asset(
                str(Path.joinpath(Path.cwd(), "lambda/cisSecurityGroupLambda"))
            ),
            timeout=Duration.seconds(60),
        )

        cisSecurityGroupLambdaCron = aws_events.Rule(
            self,
            "CisSecurityGroupLambdaCron",
            schedule=aws_events.Schedule.expression("cron(0 8 1 * ? *)"),
        )

        cisSecurityGroupLambdaCron.add_target(
            targets.LambdaFunction(cisSecurityGroupLambda)
        )

        ####################################################################################

        cisSNSTopic = sns.Topic(self, "cisSNSTopic", display_name="CISBenchmarks")

        cisMetricFilter = logs.MetricFilter(
            self,
            "CisMetricFilter",
            log_group=cisComplianceLogGroup,
            metric_name="CIS-3.1",
            metric_namespace="CISBenchmark",
            metric_value="1",
            filter_pattern=logs.FilterPattern.all_terms(
                "*UnauthorizedOperation", "AccessDenied*"
            ),
        )

        cisMetric = cisMetricFilter.metric()

        cisMetricAlarm = cloudwatch.Alarm(
            self,
            "CisMetricAlarm",
            alarm_name=PhysicalName.GENERATE_IF_NEEDED,
            metric=cisMetric,
            threshold=1,
            evaluation_periods=1,
        )

        cisMetricAlarm.add_alarm_action(actions.SnsAction(cisSNSTopic))


# example resource
# queue = sqs.Queue(
#     self, "CisComplianceQueue",
#     visibility_timeout=Duration.seconds(300),
# )
